# Project Progress — Adeel Mobile Installments

Last updated: 2026-10-31

## Completed in this delivery
- [x] Phase 01 foundation and folder architecture.
- [x] Supabase browser client configured with the project's public publishable key (no secret key).
- [x] Phase 02 login UI for Admin and User.
- [x] Username-login Edge Function source with role validation and DB-backed failed-attempt throttling.
- [x] Admin dashboard shell with exactly 12 main modules.
- [x] Customer website catalogue reads existing brands/models/variants/product_images dynamically.
- [x] User dashboard shell with exactly 8 modules.
- [x] Phase 02 additive SQL migration draft (not applied to live database).
- [x] Static local asset reference checks.

## Not complete / not yet verified
- [ ] Edge Function deployed to Supabase.
- [ ] Phase 02 migration reviewed/applied; admin alias and app_metadata role configured.
- [ ] Live admin/user login end-to-end.
- [ ] Password reset and admin user provisioning.
- [ ] Admin module workflows and database connections.
- [x] Customer website live catalogue and product detail data reads added.
- [ ] Customer verification form submission/private document upload.
- [ ] User PWA data workflows.
- [ ] Referral, advance, profit and wallet transaction processing.
- [ ] Design manager, poster generation and final 18-workflow QA.

## Existing project protection
- Existing Supabase project: `adeel-mobile-database` (`nqihozwbdrvpyalctwbc`).
- Existing catalogue tables are reused; no catalogue data copied or duplicated.
- No live schema migration or policy changes have been applied.
- No existing rows have been edited or deleted.
- Browser configuration contains only the public publishable key. Secret/service-role keys are server-only.

## Known existing database security finding
The connected project currently has RLS disabled on `public.colors` and `public.download_history`. These are exposed-table risks. This project does not change those policies automatically; remediation needs explicit review and approval.

## Remaining business confirmations
Installment advance/markup/formula/rounding; profit calculation base/percentage/rounding; repeat-customer eligibility; official logo file.
