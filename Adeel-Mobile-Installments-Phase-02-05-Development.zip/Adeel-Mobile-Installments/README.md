# Adeel Mobile Installments

Independent mobile-first business application project.

## Open in Acode
1. Extract the ZIP.
2. Open the extracted `Adeel-Mobile-Installments` folder in Acode.
3. Open `index.html` in preview/browser.

## Current delivery
Phase 01 foundation only. The application is not yet connected to Supabase and must not be used for real customer or financial records.

## Configuration
See `.env.example`. Static frontend files must contain only the Supabase URL and publishable key. Never expose a service-role/secret key.

## Project documentation
- `PROJECT_PROGRESS.md`
- `docs/ARCHITECTURE.md`
- `docs/DATABASE.md`
- `docs/SECURITY.md`
- `docs/BUSINESS_RULES.md`

## Logo
Place the official logo in `assets/logo/` after providing the original file. Until then, the UI uses a neutral text mark, not a fabricated official logo.
