import { supabase } from "../../shared/js/supabase-client.js";
import { signOut, getCurrentRole } from "../../shared/js/auth.js";

const role = await getCurrentRole();
if (!role || role !== document.body.dataset.expectedRole) {
  await signOut();
  location.replace(role === "admin" ? "../admin/index.html" : "./login.html");
}
document.querySelector("[data-logout]")?.addEventListener("click", async () => {
  await signOut();
  location.replace(role === "admin" ? "./index.html" : "./login.html");
});
const buttons = [...document.querySelectorAll("[data-module]")];
buttons.forEach(button => button.addEventListener("click", () => {
  buttons.forEach(b => b.classList.toggle("active", b === button));
  document.querySelector("[data-module-title]").textContent = button.dataset.module;
  document.querySelector("[data-module-status]").textContent =
    "Module shell tayyar hai. Is module ka live data/workflow aglay implementation batch mein connect hoga.";
}));
