# Architecture

## Applications
- `admin/`: privileged administration interface.
- `website/`: public product browsing and customer verification.
- `user-app/`: mobile-first installable PWA for assigned users.
- `shared/`: shared UI tokens, formatting, validation and business services.
- `supabase/`: versioned migrations and Edge Functions.

## Trust boundaries
Browsers are untrusted. All role checks, referral validation, verification transitions, profit calculations and wallet postings must be enforced by PostgreSQL policies or trusted Edge Functions. The browser may use only the Supabase publishable key.

## Financial invariants
Approval does not create profit. An actual advance must be recorded and confirmed before any profit posting. A unique idempotency reference and immutable ledger entry are required. Profit base, percentage semantics and rounding remain disabled pending business confirmation.
