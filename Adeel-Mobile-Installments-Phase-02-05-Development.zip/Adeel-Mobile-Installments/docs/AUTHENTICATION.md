# Authentication implementation notes

- Browser client uses the project's public publishable key only.
- Username/password login is delegated to the `username-login` Edge Function.
- Edge Function resolves username server-side, checks active alias, calls Supabase Auth password verification, and returns a short-lived session.
- The function requires server-side secrets; no service-role key is present in browser code.
- Five failed attempts per username/IP hash in a 15-minute window are throttled by a database table.
- Role must be in Supabase `app_metadata.role`; never trust `user_metadata`.
- User account alias rows can be imported from existing `public.users` records by the review-only migration.
- Admin alias setup requires the confirmed admin Auth UUID and chosen username.
- Password minimum is six characters. Four-digit PIN-only login is not implemented because it is weak and not compatible with standard secure Supabase password policy.
- Password recovery flow and admin account provisioning are still pending.
