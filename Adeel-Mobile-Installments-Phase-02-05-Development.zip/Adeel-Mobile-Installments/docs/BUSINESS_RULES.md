# Business rules awaiting owner confirmation

The application must not invent these rules.

1. Installment formula: advance calculation, markup/total price formula, rounding mode and currency precision.
2. Profit: calculation base (advance, retail price, margin or another basis), percentage application, rounding and eligibility timing.
3. Advance recording: who may record it, what evidence is required, and who confirms receipt.
4. Repeat-customer eligibility and any waiting period.
5. Verification rejection categories and required message wording.
6. PIN policy: whether four digits are mandatory or a stronger credential may be offered.
7. Referral attribution: first-touch vs last-touch and attribution expiry.
8. Customer data retention and identity-document deletion schedule.
9. Whether user profit is withdrawable wallet balance or informational earnings only.

Until confirmed, affected financial calculations and credits remain disabled.
