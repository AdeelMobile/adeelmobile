# Database architecture (design target)

Core identity:
- `profiles` maps `auth.users.id` to a role (`admin` or `user`) and account state.
- Business users are represented by profile-linked records; do not create a second password store.

Catalogue:
- `brands` → `models` → `variants`
- `product_images` belongs to a product/variant and stores private or appropriately public media metadata.
- `installment_plans` stores configurable plan definitions and rule versions.

Customer lifecycle:
- `customers`, `verifications`, `verification_documents`, `referrals`, `sales_records`, `advances`.

Financial ledger:
- `user_brand_profit`, `profit_transactions`, `wallet_transactions`.
- Financial history is append-only; corrections use compensating entries.

Configuration and audit:
- `website_settings`, `design_settings`, `activity_logs`.

All exposed tables require RLS. ID-card files belong in a private Storage bucket with narrowly scoped policies or signed URLs issued after authorization. Exact migration SQL will be added in Phase 03 after current Supabase documentation review and business-rule confirmation.
