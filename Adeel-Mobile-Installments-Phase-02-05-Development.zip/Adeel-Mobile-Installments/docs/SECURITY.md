# Security design

- Supabase Auth owns credentials and sessions; no plaintext PIN/password column.
- The requested four-digit PIN has only 10,000 possible combinations. It is weak as a standalone secret. Require server-side rate limiting, progressive lockout, monitoring, secure recovery and preferably a stronger password/passkey option. A PIN must never be treated as a cryptographic key.
- Admin role is stored in trusted server-controlled app metadata or a protected profile mapping; never authorize from user-editable metadata.
- Every user-owned table uses ownership-aware RLS, not merely `TO authenticated`.
- ID-card images are private; no public bucket URLs.
- Publishable key may be in the browser; service-role/secret keys remain server-side only.
- Referral codes are resolved and validated server-side.
- Financial operations are transactional and idempotent.
- Sensitive admin operations produce audit events.
- Never log passwords, PINs, access tokens or full identity-document contents.
