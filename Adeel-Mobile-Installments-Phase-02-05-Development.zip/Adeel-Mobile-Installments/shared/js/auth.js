import { supabase } from "./supabase-client.js";

export async function signInWithUsername(username, password) {
  const cleanUsername = String(username || "").trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,40}$/.test(cleanUsername)) {
    throw new Error("Username 3 se 40 characters ka hona chahiye.");
  }
  if (typeof password !== "string" || password.length < 6) {
    throw new Error("Password kam az kam 6 characters ka hona chahiye.");
  }

  const { data, error } = await supabase.functions.invoke("username-login", {
    body: { username: cleanUsername, password }
  });
  if (error) throw new Error("Login service available nahi. Supabase function deploy karna zaroori hai.");
  if (!data?.access_token || !data?.refresh_token || !data?.role) {
    throw new Error(data?.error || "Username ya password durust nahi.");
  }

  const { error: sessionError } = await supabase.auth.setSession({
    access_token: data.access_token,
    refresh_token: data.refresh_token
  });
  if (sessionError) throw sessionError;
  return data.role;
}

export async function getCurrentRole() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return null;
  const role = session.user?.app_metadata?.role;
  return role === "admin" || role === "user" ? role : null;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}
