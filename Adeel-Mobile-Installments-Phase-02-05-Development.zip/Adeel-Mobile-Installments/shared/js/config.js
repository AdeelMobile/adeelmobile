/* Public client configuration. Publishable key is intended for browser use.
   NEVER place a Supabase secret/service-role key in this file. */
export const appConfig = Object.freeze({
  appName: "Adeel Mobile Installments",
  environment: "development",
  supabaseUrl: "https://nqihozwbdrvpyalctwbc.supabase.co",
  supabasePublishableKey: "sb_publishable_KQG5u2pwI4QjgYMZsJ97Kw_sTPH1OeL",
  officialLogoPath: "../assets/logo/official-logo-required.svg"
});

export function isSupabaseConfigured() {
  return Boolean(appConfig.supabaseUrl && appConfig.supabasePublishableKey);
}
