import { signInWithUsername } from "./auth.js";

const form = document.querySelector("[data-login-form]");
const message = document.querySelector("[data-login-message]");
const submit = form?.querySelector('button[type="submit"]');
const toggle = document.querySelector("[data-password-toggle]");
const password = document.querySelector("#password");

toggle?.addEventListener("click", () => {
  const visible = password.type === "text";
  password.type = visible ? "password" : "text";
  toggle.textContent = visible ? "Show" : "Hide";
  toggle.setAttribute("aria-pressed", String(!visible));
});

form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "";
  submit.disabled = true;
  submit.textContent = "Please wait…";
  try {
    const role = await signInWithUsername(
      document.querySelector("#username").value,
      password.value
    );
    const expected = document.body.dataset.expectedRole;
    if (role !== expected) {
      const { supabase } = await import("./supabase-client.js");
      await supabase.auth.signOut();
      throw new Error("Is login page ke liye aapka account authorized nahi.");
    }
    location.href = role === "admin" ? "../admin/dashboard.html" : "./dashboard.html";
  } catch (error) {
    message.textContent = error.message || "Login nahi ho saka. Dobara koshish karein.";
    message.className = "form-message error";
  } finally {
    submit.disabled = false;
    submit.textContent = "Login";
  }
});
