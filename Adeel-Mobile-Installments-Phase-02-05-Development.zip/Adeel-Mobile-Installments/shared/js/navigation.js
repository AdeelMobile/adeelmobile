export const routes = Object.freeze({
  admin: "/admin/index.html",
  website: "/website/index.html",
  userApp: "/user-app/index.html"
});

export function getReferralCode(search = globalThis.location?.search ?? "") {
  const params = new URLSearchParams(search);
  return params.get("ref")?.trim() || null;
}
