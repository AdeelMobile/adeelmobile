import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";
import { appConfig, isSupabaseConfigured } from "./config.js";

if (!isSupabaseConfigured()) {
  throw new Error("Supabase configuration is missing.");
}

export const supabase = createClient(
  appConfig.supabaseUrl,
  appConfig.supabasePublishableKey,
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true
    }
  }
);
