# Edge Functions

## username-login
Purpose: map a username to its Supabase Auth account without exposing the email mapping to the browser, apply a database-backed failed-attempt throttle, then use Supabase Auth password verification.

Required server secrets (set in Supabase Edge Function secrets; never put in frontend):
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY
- SUPABASE_ANON_KEY (or SUPABASE_PUBLISHABLE_KEY)

Deploy only after reviewing and applying `migrations/PHASE02_AUTH_FOUNDATION.sql`.
Every Auth user must have matching `app_metadata.role` (`admin` or `user`) and an alias row.
Do not use user-editable `user_metadata` for authorization.
