import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};
const reply = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: cors });

async function sha256(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);

  try {
    const { username, password } = await req.json();
    const clean = String(username ?? "").trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,40}$/.test(clean) || typeof password !== "string" || password.length < 6 || password.length > 128) {
      return reply({ error: "Username ya password format durust nahi." }, 400);
    }

    const url = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const publishableKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!;
    if (!url || !serviceKey || !publishableKey) return reply({ error: "Server auth configuration missing." }, 503);

    const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const ipHash = await sha256(ip);
    const since = new Date(Date.now() - 15 * 60 * 1000).toISOString();

    const { count } = await admin.from("ims_login_attempts")
      .select("id", { count: "exact", head: true })
      .eq("username_norm", clean).eq("ip_hash", ipHash)
      .gte("created_at", since).eq("succeeded", false);
    if ((count ?? 0) >= 5) return reply({ error: "Bohat zyada attempts. 15 minutes baad dobara koshish karein." }, 429);

    const { data: alias, error: aliasError } = await admin.from("ims_auth_login_aliases")
      .select("auth_user_id, role, is_active")
      .eq("username_norm", clean).maybeSingle();

    let success = false;
    let sessionData: any = null;
    if (!aliasError && alias?.is_active) {
      const { data: authData } = await admin.auth.admin.getUserById(alias.auth_user_id);
      const email = authData?.user?.email;
      if (email) {
        const currentMetadata = authData.user.app_metadata ?? {};
        if (currentMetadata.role !== alias.role) {
          const { error: roleError } = await admin.auth.admin.updateUserById(alias.auth_user_id, {
            app_metadata: { ...currentMetadata, role: alias.role }
          });
          if (roleError) return reply({ error: "Account role configuration issue." }, 403);
        }
        const publicClient = createClient(url, publishableKey, { auth: { persistSession: false, autoRefreshToken: false } });
        const signed = await publicClient.auth.signInWithPassword({ email, password });
        if (!signed.error && signed.data.session) {
          const appRole = signed.data.user.app_metadata?.role;
          if (appRole === alias.role && (alias.role === "admin" || alias.role === "user")) {
            success = true;
            sessionData = signed.data.session;
          } else {
            await publicClient.auth.signOut();
          }
        }
      }
    }

    await admin.from("ims_login_attempts").insert({
      username_norm: clean, ip_hash: ipHash, succeeded: success
    });

    if (!success) return reply({ error: "Username ya password durust nahi, ya account inactive hai." }, 401);
    return reply({
      access_token: sessionData.access_token,
      refresh_token: sessionData.refresh_token,
      role: alias.role,
      expires_in: sessionData.expires_in
    });
  } catch (_error) {
    return reply({ error: "Login service mein masla hai. Thori dair baad koshish karein." }, 500);
  }
});
