-- REVIEW-ONLY migration for Adeel Mobile Installments.
-- This file has NOT been applied to the connected Supabase project.
-- Apply only after reviewing the existing project's schema and policies.

create table if not exists public.ims_auth_login_aliases (
  id bigint generated always as identity primary key,
  username_norm text not null unique,
  auth_user_id uuid not null unique references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','user')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.ims_login_attempts (
  id bigint generated always as identity primary key,
  username_norm text not null,
  ip_hash text not null,
  succeeded boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists ims_login_attempts_lookup_idx
  on public.ims_login_attempts (username_norm, ip_hash, created_at desc);

alter table public.ims_auth_login_aliases enable row level security;
alter table public.ims_login_attempts enable row level security;

revoke all on public.ims_auth_login_aliases from anon, authenticated;
revoke all on public.ims_login_attempts from anon, authenticated;
grant all on public.ims_auth_login_aliases to service_role;
grant all on public.ims_login_attempts to service_role;

-- Import existing user account aliases only where auth_user_id and login_username exist.
-- Does not create auth users, change passwords, or update existing user rows.
insert into public.ims_auth_login_aliases (username_norm, auth_user_id, role)
select lower(trim(login_username)), auth_user_id, 'user'
from public.users
where auth_user_id is not null
  and login_username is not null
  and trim(login_username) <> ''
on conflict do nothing;

-- Admin aliases must be inserted after confirming the intended admin auth user:
-- insert into public.ims_auth_login_aliases(username_norm, auth_user_id, role)
-- values ('YOUR_ADMIN_USERNAME', 'AUTH_USER_UUID', 'admin');
