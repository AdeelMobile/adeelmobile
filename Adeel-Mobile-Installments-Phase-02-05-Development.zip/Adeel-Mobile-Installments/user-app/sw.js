/* PWA service worker foundation. Cache strategy will be added after app routes stabilize. */
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()));
