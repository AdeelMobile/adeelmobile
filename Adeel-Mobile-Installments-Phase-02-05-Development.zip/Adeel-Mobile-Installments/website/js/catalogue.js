import { supabase } from "../../shared/js/supabase-client.js";

const grid = document.querySelector("[data-products]");
const brandsRoot = document.querySelector("[data-brands]");
const search = document.querySelector("[data-search]");
const status = document.querySelector("[data-catalogue-status]");
const money = value => new Intl.NumberFormat("en-PK", {
  style: "currency", currency: "PKR", maximumFractionDigits: 0
}).format(Number(value || 0));

let products = [];
let activeBrand = "all";

function imageFor(variant) {
  const images = [...(variant.product_images || [])].sort((a,b) =>
    Number(Boolean(b.is_cover)) - Number(Boolean(a.is_cover)) || (a.sort_order || 0) - (b.sort_order || 0)
  );
  return images[0]?.image_url || variant.image_link || "";
}

function renderBrands(brands) {
  brandsRoot.innerHTML = "";
  const all = document.createElement("button");
  all.className = "brand-filter active";
  all.textContent = "All brands";
  all.dataset.brand = "all";
  brandsRoot.append(all);
  brands.forEach(brand => {
    const button = document.createElement("button");
    button.className = "brand-filter";
    button.textContent = brand.brand;
    button.dataset.brand = String(brand.id);
    brandsRoot.append(button);
  });
  brandsRoot.addEventListener("click", event => {
    const button = event.target.closest("[data-brand]");
    if (!button) return;
    activeBrand = button.dataset.brand;
    brandsRoot.querySelectorAll(".brand-filter").forEach(b => b.classList.toggle("active", b === button));
    renderProducts();
  });
}

function renderProducts() {
  const term = (search.value || "").trim().toLowerCase();
  const filtered = products.filter(item => {
    const brandMatch = activeBrand === "all" || String(item.brand_id) === activeBrand;
    const searchMatch = `${item.brand} ${item.model} ${item.variant}`.toLowerCase().includes(term);
    return brandMatch && searchMatch;
  });
  grid.innerHTML = "";
  if (!filtered.length) {
    status.textContent = "Is search mein koi product nahi mila.";
    return;
  }
  status.textContent = `${filtered.length} products`;
  filtered.forEach(item => {
    const card = document.createElement("article");
    card.className = "catalogue-card";
    const img = document.createElement("img");
    img.loading = "lazy";
    img.alt = `${item.brand} ${item.model}`;
    img.src = item.image || "../assets/product-placeholder.svg";
    img.onerror = () => { img.src = "../assets/product-placeholder.svg"; };
    const body = document.createElement("div");
    body.className = "catalogue-card-body";
    const brand = document.createElement("p"); brand.className = "catalogue-brand"; brand.textContent = item.brand;
    const title = document.createElement("h3"); title.textContent = item.model;
    const variant = document.createElement("p"); variant.className = "catalogue-variant"; variant.textContent = item.variant;
    const price = document.createElement("p"); price.className = "catalogue-price";
    const displayPrice = item.discount_price && Number(item.discount_price) > 0 ? item.discount_price : item.price;
    price.textContent = money(displayPrice);
    const actions = document.createElement("div"); actions.className = "catalogue-actions";
    const details = document.createElement("a"); details.className = "catalogue-link";
    details.href = `product.html?variant=${encodeURIComponent(item.variant_id)}${location.search}`;
    details.textContent = "View details";
    const share = document.createElement("button"); share.className = "catalogue-share"; share.textContent = "Share";
    share.addEventListener("click", async () => {
      const url = new URL(details.href, location.href).href;
      const text = `${item.brand} ${item.model} ${item.variant} — ${money(displayPrice)}\n${url}`;
      if (navigator.share) await navigator.share({ title: `${item.brand} ${item.model}`, text, url });
      else location.href = `https://wa.me/?text=${encodeURIComponent(text)}`;
    });
    actions.append(details, share);
    body.append(brand, title, variant, price, actions);
    card.append(img, body);
    grid.append(card);
  });
}

async function loadCatalogue() {
  status.textContent = "Products load ho rahe hain…";
  const { data: brands, error: brandError } = await supabase.from("brands")
    .select("id,brand,show_brand,show_inst_website")
    .eq("show_brand", true).eq("show_inst_website", true).order("brand");
  if (brandError) throw brandError;
  const { data: models, error: modelError } = await supabase.from("models")
    .select("id,brand_id,model,status,show_inst_website")
    .eq("status", "active").eq("show_inst_website", true).order("sort_order");
  if (modelError) throw modelError;
  const { data: variants, error: variantError } = await supabase.from("variants")
    .select("id,model_id,variant,price,discount_price,show_website,image_link,gallery_images,specs,product_images(image_url,color,sort_order,is_cover)")
    .eq("show_website", true).order("id");
  if (variantError) throw variantError;

  const brandMap = new Map(brands.map(b => [b.id, b.brand]));
  const modelMap = new Map(models.map(m => [m.id, m]));
  products = variants.flatMap(v => {
    const model = modelMap.get(v.model_id);
    if (!model || !brandMap.has(model.brand_id)) return [];
    return [{
      brand_id: model.brand_id, brand: brandMap.get(model.brand_id),
      model: model.model, variant: v.variant, variant_id: v.id,
      price: v.price, discount_price: v.discount_price, image: imageFor(v)
    }];
  });
  renderBrands(brands);
  renderProducts();
}

search.addEventListener("input", renderProducts);
loadCatalogue().catch(error => {
  console.error(error);
  status.textContent = "Catalogue load nahi ho saka. Supabase RLS/API access check karein.";
});
