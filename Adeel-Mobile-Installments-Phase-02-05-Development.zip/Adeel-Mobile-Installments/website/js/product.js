import { supabase } from "../../shared/js/supabase-client.js";

const root = document.querySelector("[data-product-detail]");
const params = new URLSearchParams(location.search);
const id = Number(params.get("variant"));
const ref = params.get("ref");
if (!Number.isSafeInteger(id) || id < 1) {
  root.textContent = "Product link durust nahi.";
} else {
  const { data: variant, error } = await supabase.from("variants")
    .select("id,variant,price,discount_price,image_link,gallery_images,specs,show_website,models(model,brands(brand)),product_images(image_url,color,sort_order,is_cover)")
    .eq("id", id).eq("show_website", true).maybeSingle();
  if (error || !variant) {
    root.textContent = "Product available nahi ya website par hidden hai.";
  } else {
    const model = variant.models;
    const brand = Array.isArray(model?.brands) ? model.brands[0] : model?.brands;
    const images = [...(variant.product_images || [])].sort((a,b) =>
      Number(Boolean(b.is_cover)) - Number(Boolean(a.is_cover)) || (a.sort_order || 0) - (b.sort_order || 0)
    );
    const image = images[0]?.image_url || variant.image_link || "../assets/product-placeholder.svg";
    const price = Number(variant.discount_price || variant.price || 0);
    const money = new Intl.NumberFormat("en-PK",{style:"currency",currency:"PKR",maximumFractionDigits:0}).format(price);
    root.innerHTML = `<div class="detail-image"><img src="${image}" alt="Product image"></div>
      <div><p class="eyebrow">${brand?.brand || "Adeel Mobile"}</p><h1>${model?.model || "Mobile"}</h1>
      <h2>${variant.variant}</h2><p class="detail-price">${money}</p>
      <p class="muted">Installment advance, markup aur rounding rules business confirmation ke intezar mein hain. Is liye abhi installment quote display nahi kiya ja raha.</p>
      <button class="primary-btn" data-verify>Verify Now</button></div>`;
    root.querySelector("[data-verify]").addEventListener("click", () => {
      const url = new URL("verification.html", location.href);
      url.searchParams.set("variant", String(id));
      if (ref) url.searchParams.set("ref", ref);
      location.href = url.href;
    });
    const specs = variant.specs && typeof variant.specs === "object" ? variant.specs : null;
    if (specs) {
      const list = document.createElement("dl"); list.className = "spec-list";
      Object.entries(specs).forEach(([key,value]) => {
        const dt=document.createElement("dt"); dt.textContent=key;
        const dd=document.createElement("dd"); dd.textContent=String(value);
        list.append(dt,dd);
      });
      root.append(list);
    }
  }
}
